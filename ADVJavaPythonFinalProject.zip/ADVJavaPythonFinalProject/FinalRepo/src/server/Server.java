package server;

public class Server {
}
