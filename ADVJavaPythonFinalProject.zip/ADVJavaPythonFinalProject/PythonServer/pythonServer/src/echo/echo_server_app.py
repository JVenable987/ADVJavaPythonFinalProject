from echoServer import Server

if __name__ == "__main__":
    server = Server("localhost", 10000, 5)

    server.run()
